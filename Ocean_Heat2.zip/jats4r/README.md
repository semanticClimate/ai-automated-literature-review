# jats2html
XProc library and XSLT stylesheets to convert JATS to HTML
